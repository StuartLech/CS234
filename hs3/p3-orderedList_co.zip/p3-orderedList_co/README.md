# p3 - orderedList - 10 pts

## Preview Instructions (VSC)
This document is written using `Markdown` and this format includes mark-up syntax along with textual content. In order to view the formatted document do one of two things:

1. Press `Shift + cmd + V` or `Shift + ctrl + V` on a **Mac** or **Win** PC respectively.
1. Right click on the file tab and select `Open Preview`.

Viewing the document in its formatted version will make it easier to read and follow format requirements and file names.


## Submission Instructions
Upload your `p3` folder to [Moodle](classes.cs.siue.edu).


## Problem Instructions
In this assignment you are to create a web page that includes an unordered list.

*__Hint:__* As you develop the page use your browser to test out the site. 

1. Run `MAMP` to start up the web server. This will allow you to test the site as you implement each step and find any errors early during development.

1. Create the file `p3.html` under the `htdocs\hs3\p3` folder. This file will represent your web page for this assignment. Make sure all downloaded files (*.png, *.html, *.md) are moved into this folder as well.

1. Create the page skeleton by adding the elements `<!DOCTYPE>, <html>, <head>, <title> and <body>`. You will be adding to each the missing components as you follow these instructions.

1. Add the content `"p3-orderedList"` to the `<title>` element.

1. Add a `<p>` element to the `<body>`.
1. Add an `<h1>` element with content `"p3-Ordered List"` to the paragraph above.

1. Create the following ordered list in the body next. 

    ```
    1. North America
        1. Canada
        2. USA
        3. Mexico
        4. Guatemala
    2. South America
        1. Colombia
        2. Venezuela
        3. Brazil
        4. Argentina
    3. Europe
        1. United Kingdom
        2. France
        3. Spain
        4. Portugal   
    ```

1. Make each continent name a link by enclosing it in `<a>` elements. Use `continents.html` provided with the homework folder as each link's reference.

1. Edit the `src` and `alt` attributes of each of the the three `<img>` elements inside the file `continents.html` to add the following content to each respectively.

    * `northAmerica.png`, `"North America"`
    * `southAmerica.png`, `"South America"`
    * `europe.png`, `"Europe"`

1. Add a `<footer>` element to the body next.
1. Add the copyright &copy; 2021 `your name here` to the footer.

1. Verify and upload your submission.