# p3 - list - 10 pts

## Preview Instructions (VSC)
This document is written using `Markdown` and this format includes mark-up syntax along with textual content. In order to view the formatted document do one of two things:

1. Press `Shift + cmd + V` or `Shift + ctrl + V` on a **Mac** or **Win** PC respectively.
1. Right click on the file tab and select `Open Preview`.

Viewing the document in its formatted version will make it easier to read and follow format requirements and file names.


## Submission Instructions
Upload your `p3` folder to [Moodle](classes.cs.siue.edu).


## Problem Instructions
In this assignment you are to style a web page using the `W3.CSS` framework from `w3schools.com`.

*__Hint:__* As you develop the page use your browser to test out the site. 

1. Run `MAMP` to start up the web server. This will allow you to test the site as you implement each step and find any errors early during development.

1. Move the file `p3.html` to the `htdocs\hs5\p3` folder. This file will represent your web page for this assignment.

    #### Link to the W3.CSS framework
1. Add a `<link>` element with the attribute `href="htttps://www.w3schools.com/w3css/4/w3.css"`. The link element will make the CSS framework available while online. This method of linking uses the `CDN (Content Delivery Network)` rather than downloading a copy of framework to your local host.

    #### Style the `<h1>` element
1. Add the classes `w3-red`, and `w3-center` to center the contents of the `<h1>` element and make the background *red*. 

    #### Style the North America `<ul>` element
1. Add the classes `w3-border`, `w3-margin`, `w3-ul`, and `w3-hoverable` to style the list with a border, an all-around margin and give it a hoverable effect.

    #### Style the NA `<li>` element
1. Add the class `w3-lime` to highlight the list's caption.

   #### Style the South America `<ul>` element
1. Add the classes `w3-margin`, `w3-ul`, and `w3-hoverable` to style the list with an all-around margin and give it a hoverable effect.

    #### Style the SA `<li>` element
1. Add the class `w3-green` to highlight the list's caption.

   #### Style the Europe `<ul>` element
1. Add the classes `w3-margin`, `w3-card-4`, `w3-ul`, and `w3-hoverable` to style the list with an all-around margin, make it a card and give it a hoverable effect.
1. Add the attribute `style="width:60%"` to limit the width of the list to 60% of it container.

    #### Style the EU `<li>` element
1. Add the class `w3-blue` to highlight the list's caption.

    #### Style the `<footer>` element
1. Add the classes `w3-panel`, `w3-center`, `w3-small`, and `w3-text-gray` to center the footer, make it smaller and change its color so its not as noticeable, but still relevant.
1. Type your name in the copyright line.

1. Verify and upload your submission.